// lib/services/cure_ble_transport_native.dart

import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart'; // for kDebugMode, debugPrint

import 'cure_ble_transport.dart';

/// Native MethodChannel/EventChannel based transport for CureBase.
class CureBleTransportNative implements CureBleTransport {
  static const MethodChannel _method =
      MethodChannel('cure_ble_native/methods');
  static const EventChannel _notifyChannel =
      EventChannel('cure_ble_native/notify');

  final StreamController<String> _notifyCtrl =
      StreamController<String>.broadcast();
  StreamSubscription<dynamic>? _eventSub;

  CureBleTransportNative() {
    _eventSub = _notifyChannel.receiveBroadcastStream().listen((event) {
      try {
        // Variante: Native sendet Maps: { type: "line", data: "..." }
        if (event is Map) {
          final type = event['type'];
          if (type == 'line') {
            final data = event['data'];
            if (data is String) {
              _notifyCtrl.add(data.trim());
            }
          } else if (type == 'state') {
            final state = event['state'];
            final deviceId = event['deviceId'];
            if (kDebugMode) {
              debugPrint('[NativeTransport] state event: state=$state deviceId=$deviceId');
            }
          } else if (type == 'error') {
            final msg = event['message'];
            if (kDebugMode) debugPrint('[NativeTransport] native error: $msg');
          }
        }
        // Fallback: Native sendet direkt Strings
        else if (event is String) {
          _notifyCtrl.add(event.trim());
        }
      } catch (e, st) {
        if (kDebugMode) debugPrint('CureBleTransportNative: notify event parse error: $e\n$st');
      }
    }, onError: (e) {
      if (kDebugMode) debugPrint('CureBleTransportNative: notify stream error: $e');
    });
  }

  @override
  String get id => 'native';

  @override
  Stream<String> get notifyLines => _notifyCtrl.stream;

  @override
  Future<void> connect(String deviceId) async {
    await _method.invokeMethod('connect', {'deviceId': deviceId});
  }

  @override
  Future<void> disconnect() async {
    await _method.invokeMethod('disconnect');
  }

  @override
  Future<void> writeLine(String line) async {
    await _method.invokeMethod('writeLine', {'line': line});
  }

  @override
  Future<List<String>> sendCommandAndWaitLines(
    String line, {
    Duration timeout = const Duration(seconds: 30),
  }) async {
    if (kDebugMode) debugPrint('[NativeTransport] sendCommandAndWaitLines: $line (timeout: ${timeout.inMilliseconds}ms)');
    final resp = await _method.invokeListMethod<String>(
      'sendCommandAndWaitLines',
      {
        'line': line,
        'timeoutMs': timeout.inMilliseconds,
      },
    );
    if (kDebugMode) debugPrint('[NativeTransport] sendCommandAndWaitLines result: $resp');
    if (resp != null) {
      return resp.whereType<String>().toList();
    }
    return const <String>[];
  }

  Future<void> runSignRoundtripTest({
    required String deviceId,
    void Function(String msg)? onLog,
  }) async {
    try {
      onLog?.call('Connecting to device...');
      await connect(deviceId);

      onLog?.call('Requesting challenge...');
      final challengeLines = await sendCommandAndWaitLines('challenge', timeout: Duration(seconds: 10));
      final challengeHex = challengeLines.firstWhere(
        (line) => RegExp(r'^[0-9A-Fa-f]{64}$').hasMatch(line.trim()),
        orElse: () => '',
      );

      if (challengeHex.isEmpty) {
        onLog?.call('Failed to retrieve challenge.');
        return;
      }

      onLog?.call('Challenge received: $challengeHex');
      final signCmd = 'sign=$challengeHex';

      onLog?.call('Requesting device signature...');
      final signLines = await sendCommandAndWaitLines(signCmd, timeout: Duration(seconds: 10));
      final signatureHex = signLines.firstWhere(
        (line) => RegExp(r'^[0-9A-Fa-f]{128}$').hasMatch(line.trim()),
        orElse: () => '',
      );

      if (signatureHex.isEmpty) {
        onLog?.call('Failed to retrieve signature.');
        return;
      }

      onLog?.call('Signature received: $signatureHex');
      final isValid = await CureBleTransportNative._method.invokeMethod<bool>(
        'verifyDeviceSignature',
        {'challengeHex': challengeHex, 'sigHex': signatureHex},
      );

      if (isValid == true) {
        onLog?.call('Device sign() verification: OK');
      } else {
        onLog?.call('Device sign() verification: FAILED');
      }
    } catch (e) {
      onLog?.call('Error during sign roundtrip test: $e');
    } finally {
      onLog?.call('Disconnecting from device...');
      await disconnect();
    }
  }

  void dispose() {
    _eventSub?.cancel();
    _notifyCtrl.close();
  }
}
